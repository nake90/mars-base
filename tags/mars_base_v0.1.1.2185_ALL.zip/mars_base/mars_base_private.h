/* THIS FILE WILL BE OVERWRITTEN BY DEV-C++ */
/* DO NOT EDIT ! */

#ifndef MARS_BASE_PRIVATE_H
#define MARS_BASE_PRIVATE_H

/* VERSION DEFINITIONS */
#define VER_STRING	"0.1.1.2185"
#define VER_MAJOR	0
#define VER_MINOR	1
#define VER_RELEASE	1
#define VER_BUILD	2185
#define COMPANY_NAME	""
#define FILE_VERSION	""
#define FILE_DESCRIPTION	"Design, build and maintain your own Mars-base"
#define INTERNAL_NAME	""
#define LEGAL_COPYRIGHT	"GNU-GPL (c) by Alfonso Arbona Gimeno (All rights reserved)"
#define LEGAL_TRADEMARKS	""
#define ORIGINAL_FILENAME	""
#define PRODUCT_NAME	"mars-base"
#define PRODUCT_VERSION	""

#endif /*MARS_BASE_PRIVATE_H*/
