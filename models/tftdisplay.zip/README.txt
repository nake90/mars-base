This Model was downloaded from 3D-Resources.com
http://www.3d-resources.com

Software 3D Studio Max

Contents of this file 

TFTDisplay.3DS

Credit for this model goes out to : CYGAD

Hope to see you back soon on 

3D-Resources.com



