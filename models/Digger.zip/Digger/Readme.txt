3ds Max 6 model of digger/earthmover.

Rigged by using the robot arm tutorial from 3dnuts.(thanks guys)

Standard textures that ship with 3ds6

use at your own risk. It's not my fault if your disk drive explodes.

You are free to use this model in your own scenes but please, include this readme & don't sell it on.

Any questions...

wozza_@hotmail.com

Hope its some help

Warwick Shaw 20/05/2005